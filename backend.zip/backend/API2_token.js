const token1 = "sk-UAMh65f46ecb9f5a64704"
const token2 = "sk-jOei65f47a3ec08b74715"
const token3 = "sk-1VPS65f47a8b600924716"
const token4 = "sk-5GXF65f47acac16764717"
const token5 = "sk-V8HK65f47b00b568a4718"
const token6 = "sk-4Uij65f47b3c50b0e4719"  
const token7 = "sk-5KTv65f47b96784d24720"
const token8 = "sk-ocvZ65f47bd4745ee4721"
const token9 = "sk-p4lW65f47c138c1dd4722"
const token10 = "sk-yWgR65f47c698bac94723"
const token11 = "sk-ZIh765f47cb6adc444724"
const token12 = "sk-4WmA65f47cfa2994d4725"
const token13 = "sk-9aSC65f47d2d4610e4726"
const token14 = "sk-Hy3j65f47d728dba04727"
const token15 = "sk-Dzxv65f47dc14a52f4728"
const token16 = "sk-FyHs65f47e0b5a0694729"  
const token17 = "sk-JGrK65f47e467569c4730"
const token18 = "sk-2yYf65f47eefa43414732"
const token19 = "sk-RRFk65f47f4c9089f4733"
const token20 = "sk-9hT565f47f93dfcec4734"
const token21 = "sk-JX1K65f48427a5a2f4735"
const token22 = "sk-xshW65f484708d11a4736"
const token23 = "sk-sFGM65f484ae2517b4737"
const token24 = "sk-gqtO65f484e614eb44738"
const token25 = "sk-GOn965f48522eac8c4739"
const token26 = "sk-WF2K65f486771b6bd4740"  
const token27 = "sk-snjs65f486d7d30af4741"
const token28 = "sk-4daJ65f4871c57ea84742"
const token29 = "sk-jBll65f487657a8dd4743"
const token30 = "sk-rW8D65f487a79984d4744"
const token31 = "sk-4XgI65f487f51f3474745"
const token32 = "sk-P7MW65f48a2094a734746"
const token33 = "sk-No6665f463596274f4668"
const token34 = "sk-DsfX65f4639cc3e274678"
const token35 = "sk-QWPB65f463ebdde124679"
const token36 = "sk-jc3N65f4642e499de4681"  
const token37 = "sk-jBbo65f46466682a44683"
const token38 = "sk-OvVU65f464d54d55f4687"
const token39 = "sk-a1Ke65f4650cb7cae4689"
const token40 = "sk-7tvc65f465683452d4692"
const token41 = "sk-aqJl65f43ce18a5884656"
const token42 = "sk-UuIi65f43ca524e4c4655"
const token43 = "sk-usFP65f46623e41764697"
const token44 = "sk-kMFy65f466763d59a4698"
const token45 = "sk-7cf665f466b4f2c9f4699"
const token46 = "sk-Zn6C65f4681b8556e4700"  
const token47 = "sk-3Ui465f469320f71e4701"
const token48 = "sk-MQXD65f469ac679194702"
const token49 = "sk-TkxI65f469ee2a3224703"
const token50 = "sk-UAMh65f46ecb9f5a64704"

module.exports ={
    token1,
    token2,
    token3,
    token4,
    token5,
    token6,
    token7,
    token8,
    token9,
    token10,
    token11,
    token12,
    token13,
    token14,
    token15,
    token16,
    token17,
    token18,
    token19,
    token20,
    token21,
    token22,
    token23,
    token24,
    token25,
    token26,
    token27,
    token28,
    token29,
    token30,
    token31,
    token32,
    token33,
    token34,
    token35,
    token36,
    token37,
    token38,
    token39,
    token40,
    token41,
    token42,
    token43,
    token44,
    token45,
    token46,
    token47,
    token48,
    token49,
    token50,
}