const API_token = "4XvpVa8ZZxPPOaBd-9_RD60ap7zdi9PpnI8TnNZcLKM"

module.exports = API_token;