-- AlterTable
ALTER TABLE "Plant" ADD COLUMN     "description" TEXT NOT NULL DEFAULT 'No description';
