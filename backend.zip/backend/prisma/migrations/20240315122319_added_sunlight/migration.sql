-- AlterTable
ALTER TABLE "Plant" ADD COLUMN     "sunlight" TEXT;
