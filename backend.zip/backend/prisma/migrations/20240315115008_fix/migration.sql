-- AlterTable
ALTER TABLE "Plant" ALTER COLUMN "volume_water_requirement_value" SET DATA TYPE TEXT,
ALTER COLUMN "watering_general_benchmark_value" SET DATA TYPE TEXT;
